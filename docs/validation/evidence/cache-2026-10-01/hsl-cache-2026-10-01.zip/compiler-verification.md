# Compiler verification

Inspected Release executables built with Xcode 26.5 / Swift 6.3.2. Full disassembly, demangled indirect-symbol tables, specialized scenario loops, and compiler-index.json are retained. Their binary hashes match raw.json.

| Checked call | Baseline | HSL direct |
| --- | --- | --- |
| Palette preparation | 0x1000cbc54 | 0x1000ca848 |
| Palette first now / uptime | 0x1000cbc5c / 0x1000cbc64 | 0x1000ca850 / 0x1000ca858 |
| Palette input / dispatch / sink | 0x1000cbca8 / 0x1000cbcbc / 0x1000cbcd8 | 0x1000ca89c / 0x1000ca8b0 / 0x1000ca8cc |
| Palette second now / uptime | 0x1000cbce8 / 0x1000cbcf0 | 0x1000ca8dc / 0x1000ca8e4 |
| Palette loop back edge | 0x1000cbd10 | 0x1000ca904 |
| HSL preparation | 0x1000cd8b8 | 0x1000cc4ac |
| HSL first now / uptime | 0x1000cd8c0 / 0x1000cd8c8 | 0x1000cc4b4 / 0x1000cc4bc |
| HSL input / dispatch / sink | 0x1000cd8f8 / 0x1000cd908 / 0x1000cd91c | 0x1000cc4ec / 0x1000cc4fc / 0x1000cc510 |
| HSL second now / uptime | 0x1000cd924 / 0x1000cd92c | 0x1000cc518 / 0x1000cc520 |
| HSL loop back edge | 0x1000cd94c | 0x1000cc540 |

Both request loops keep preparation before timing and consume the complete result inside it. HSL and LAB share an optional-triple measurement specialization, identified by its LAB tuple spelling.

Baseline palette closure calls public generateAssessedPalette at 0x1000c4b2c (target 0x100030e68); candidate at 0x1000c3678 (target 0x10002fffc). The public generation/assessment source is unchanged.

Baseline HSL closure at 0x1000d0788 loads public hslComponents at 0x100045184 and branches to merged conversion trampoline 0x1000d088c, which invokes it at 0x1000d08a0. Candidate closure 0x1000cf37c contains the inlined HSL body: resolution call at 0x1000cf398 targets AppearanceResolvedSRGBA.resolve (0x1000a88fc), followed by clamping and the HSL formula call at 0x1000cf3e8 targeting SRGBColorConversion.hsl (0x10006e900). The computation has not been optimized away. Inlining differences are part of the measured optimized implementations, not evidence isolating NSCache storage cost.

Clock stubs: baseline now/uptime 0x1000d2de0 / 0x1000d2dd4; candidate 0x1000d1a50 / 0x1000d1a44. Addresses are specific to retained executable hashes.
