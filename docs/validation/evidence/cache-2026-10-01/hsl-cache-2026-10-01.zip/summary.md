# HSL-only cache comparison

Microseconds per complete request; median [min–max] of 30 sample means. Controls are not subtracted.

| Scenario | Preparation | Current cache | HSL direct | HSL direct minus current | Median control: current / HSL direct |
| --- | --- | ---: | ---: | ---: | ---: |
| palette-blue-white-5-seed-42 | empty | 45.139 [43.255–46.792] | 36.263 [34.810–37.619] | -8.876 (-19.7%) | 0.020 / 0.020 |
| palette-blue-white-5-seed-42 | primed | 30.024 [29.153–33.226] | 32.563 [31.198–37.316] | +2.539 (+8.5%) | 0.023 / 0.022 |
| palette-blue-white-8-seed-42 | empty | 2321.827 [2210.362–2383.155] | 2188.037 [2136.941–2236.659] | -133.790 (-5.8%) | 0.018 / 0.018 |
| palette-blue-white-8-seed-42 | primed | 2111.247 [2066.543–2145.292] | 1983.078 [1914.397–2008.161] | -128.169 (-6.1%) | 0.050 / 0.050 |
| hsl-red | empty | 2.865 [2.723–3.313] | 1.274 [1.185–1.460] | -1.590 (-55.5%) | 0.015 / 0.016 |
| hsl-red | primed | 0.991 [0.947–1.140] | 1.260 [1.184–1.395] | +0.269 (+27.1%) | 0.021 / 0.014 |
