from pathlib import Path
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parent
summary = {}
for variant in ['baseline', 'hsl-direct']:
    binary = ROOT / variant / 'Benchmarks/.build/release/ColorKitBenchmarks'
    disassembly = subprocess.check_output(['xcrun', 'llvm-objdump', '--disassemble', '--demangle', str(binary)])
    disassembly = subprocess.check_output(['xcrun', 'swift-demangle'], input=disassembly).decode()
    indirect = subprocess.check_output(['xcrun', 'llvm-objdump', '--macho', '--indirect-symbols', str(binary)])
    indirect = subprocess.check_output(['xcrun', 'swift-demangle'], input=indirect).decode()
    (ROOT / (variant + '-disassembly.txt')).write_text(disassembly)
    (ROOT / (variant + '-indirect-symbols.txt')).write_text(indirect)
    clock = [s for s in indirect.splitlines() if 'Dispatch.DispatchTime' in s and ('now()' in s or 'uptimeNanoseconds' in s)]
    lines = disassembly.splitlines()
    starts = [i for i, s in enumerate(lines) if re.match(r'^[0-9a-f]+ <', s) and s.endswith('>:')]
    blocks = [lines[a:b] for a, b in zip(starts, starts[1:] + [len(lines)])]
    loops = []
    for block in blocks:
        name = block[0]
        if 'generic specialization <' in name and 'of closure #4 ' in name and 'Scenario.init' in name and 'partial apply' not in name:
            loops.append(block)
    (ROOT / (variant + '-scenario-loops.txt')).write_text('\n\n'.join('\n'.join(b) for b in loops))
    summary[variant] = {'binarySHA256': hashlib.sha256(binary.read_bytes()).hexdigest(), 'clockStubs': clock, 'loopHeaders': [b[0] for b in loops]}
    print(variant, 'clock stubs:', *clock, sep='\n')
    print('Specialized loop headers:')
    for block in loops:
        print(block[0][:300])
    print('Public operation calls inside benchmark closures:')
    for block in blocks:
        if 'closure #' in block[0] and ('ColorKitBenchmarks.scenarios()' in block[0] or '(paletteScenario in' in block[0]):
            for line in block[1:]:
                if '\tbl\t' in line and ('hslComponents()' in line or 'generateAssessedPalette<' in line):
                    print(line)
(ROOT / 'compiler-index.json').write_text(json.dumps(summary, indent=2) + '\n')
