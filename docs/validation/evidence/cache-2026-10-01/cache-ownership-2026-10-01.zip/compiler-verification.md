# Compiler verification

Both executables were built with Xcode 26.5, Swift 6.3.2, Release. Full llvm-objdump disassembly (passed through swift-demangle), indirect-symbol tables, and extracted palette run closures are retained alongside this note. Hashes match raw.json.

| Checked call in the palette request loop | Baseline | Direct |
| --- | --- | --- |
| Preparation dispatch | 0x1000cb898 | 0x1000c9718 |
| First DispatchTime.now | 0x1000cb8a0 | 0x1000c9720 |
| First uptimeNanoseconds | 0x1000cb8a8 | 0x1000c9728 |
| Opaque input | 0x1000cb8ec | 0x1000c976c |
| Operation dispatch | 0x1000cb8fc | 0x1000c977c |
| Full result consume | 0x1000cb918 | 0x1000c9798 |
| Second DispatchTime.now | 0x1000cb928 | 0x1000c97a8 |
| Second uptimeNanoseconds | 0x1000cb930 | 0x1000c97b0 |
| Loop back edge | 0x1000cb950 | 0x1000c97d0 |
| Operation closure calls public generateAssessedPalette | 0x1000c4b2c | 0x1000c29ac |
| Public RNG-bearing assessed request target | 0x100030e68 | 0x10002fb78 |

The indirect-symbol tables identify the baseline now/uptime stubs as 0x1000d2788/0x1000d277c and the direct stubs as 0x1000d0684/0x1000d0678. The public assessed request still generates then assesses every returned entry; its source is unchanged. Preparation precedes timing. The full-array sink remains inside timing. These addresses apply only to the retained binaries, not future recompilations.
