"""Isolated approved comparison; keeps the repository's request timer unchanged."""
from pathlib import Path
import datetime
import hashlib
import json
import platform
import statistics
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
NAMES = ['palette-blue-white-5-seed-42', 'palette-blue-white-8-seed-42']
PAIRS = [(name, mode) for name in NAMES for mode in ['empty', 'primed']]
BINARIES = {v: ROOT / v / 'Benchmarks/.build/release/ColorKitBenchmarks' for v in ['baseline', 'direct']}

def command(*args):
    return subprocess.check_output(args, text=True).strip()

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def validate(records):
    references = {}
    descriptions = {}
    for record in records:
        name = record['scenario']['id']
        if name in references and references[name] != record['diagnostics']:
            raise RuntimeError('Cross-variant/run/preparation diagnostics mismatch: ' + name)
        if name in descriptions and descriptions[name] != record['scenario']:
            raise RuntimeError('Scenario description mismatch: ' + name)
        references[name] = record['diagnostics']
        descriptions[name] = record['scenario']

def run(variant, name, mode, samples, iterations):
    args = [str(BINARIES[variant]), name, mode, str(samples), str(iterations)]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    completed = subprocess.run(args, text=True, capture_output=True)
    if completed.returncode:
        (ROOT / 'failed-process.json').write_text(json.dumps({'command': args, 'stdout': completed.stdout, 'stderr': completed.stderr, 'returncode': completed.returncode}, indent=2))
        raise RuntimeError('Benchmark process failed: ' + ' '.join(args))
    value = json.loads(completed.stdout)
    value.update(variant=variant, command=args, timestampUTC=started)
    return value

def metadata():
    return {
        'timestampUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'revision': json.loads((ROOT / 'source-manifest.json').read_text())['revision'],
        'invocation': sys.argv,
        'candidatePatch': (ROOT / 'candidate.patch').read_text(),
        'harnessSources': {str(p.relative_to(ROOT / 'baseline')): p.read_text() for p in sorted((ROOT / 'baseline/Benchmarks/Sources').rglob('*.swift'))},
        'driver': Path(__file__).read_text(),
        'binarySHA256': {v: digest(p) for v, p in BINARIES.items()},
        'configuration': 'release',
        'swift': command('swift', '--version'), 'xcode': command('xcodebuild', '-version'),
        'sdk': command('xcrun', '--show-sdk-version'), 'os': command('sw_vers'),
        'architecture': platform.machine(), 'hardwareModel': command('sysctl', '-n', 'hw.model'),
        'cpu': command('sysctl', '-n', 'machdep.cpu.brand_string'),
        'memoryBytes': int(command('sysctl', '-n', 'hw.memsize')), 'power': command('pmset', '-g', 'batt'),
        'processesBeforeSampling': command('ps', '-axo', 'pid,comm'),
        'runs': 3, 'samplesPerRun': 10, 'requestsPerSample': 100, 'warmupRequests': 10,
        'preflight': 'Separate 1-sample/100-request executions only to validate diagnostics before main sampling; their timings are not analyzed.',
        'sampling': 'Baseline/direct order alternates for adjacent matched pairs and reverses by run; fixture/preparation order reverses in run 2. Request/control sample order alternates in the unchanged harness.',
    }

def verify_sources():
    manifest = json.loads((ROOT / 'source-manifest.json').read_text())
    for variant, paths in manifest['files'].items():
        for relative, sha in paths.items():
            if digest(ROOT / variant / relative) != sha:
                raise RuntimeError('Source changed: ' + variant + '/' + relative)

def preflight():
    path = ROOT / 'preflight.json'
    if path.exists():
        raise RuntimeError('Refusing to overwrite preflight')
    verify_sources()
    artifact = {'complete': False, 'binarySHA256': {v: digest(p) for v, p in BINARIES.items()}, 'records': []}
    for name, mode in PAIRS:
        for variant in BINARIES:
            print('Validate', variant, name, mode, flush=True)
            artifact['records'].append(run(variant, name, mode, 1, 100))
            path.write_text(json.dumps(artifact, indent=2) + '\n')
            validate(artifact['records'])
    artifact['complete'] = True
    path.write_text(json.dumps(artifact, indent=2) + '\n')
    print('All cross-variant diagnostics match', flush=True)

def sample():
    path = ROOT / 'raw.json'
    if path.exists():
        raise RuntimeError('Refusing to overwrite raw samples')
    verify_sources()
    preflight_artifact = json.loads((ROOT / 'preflight.json').read_text())
    assert preflight_artifact['complete']
    assert preflight_artifact['binarySHA256'] == {v: digest(p) for v, p in BINARIES.items()}
    artifact = {'schemaVersion': 1, 'complete': False, 'environment': metadata(), 'records': []}
    def save():
        path.write_text(json.dumps(artifact, indent=2) + '\n')
    save()
    try:
        for run_index in range(3):
            for pair_index, (name, mode) in enumerate(PAIRS if run_index % 2 == 0 else PAIRS[::-1]):
                variants = ['baseline', 'direct'] if (pair_index + run_index) % 2 == 0 else ['direct', 'baseline']
                for variant in variants:
                    print('Run', run_index + 1, variant, name, mode, flush=True)
                    value = run(variant, name, mode, 10, 100)
                    value.update(run=run_index + 1, order=len(artifact['records']) + 1)
                    artifact['records'].append(value)
                    save()
                    validate(preflight_artifact['records'] + artifact['records'])
        artifact['complete'] = True
    except BaseException as error:
        artifact['error'] = repr(error)
        raise
    finally:
        save()
    summarize(artifact)

def summarize(artifact):
    lines = ['# Cache ownership comparison', '', 'Microseconds per complete request; median [min–max] of 30 sample means. Controls are not subtracted.', '', '| Size | Preparation | Current cache | Direct computation | Direct minus current | Median control: current / direct |', '| --- | --- | ---: | ---: | ---: | ---: |']
    summaries = []
    for name, mode in PAIRS:
        values = {}
        controls = {}
        by_run = {}
        for variant in BINARIES:
            records = [r for r in artifact['records'] if r['scenario']['id'] == name and r['cacheMode'] == mode and r['variant'] == variant]
            values[variant] = [s['requestNanoseconds'] / s['requestCount'] / 1000 for r in records for s in r['samples']]
            controls[variant] = [s['controlNanoseconds'] / s['requestCount'] / 1000 for r in records for s in r['samples']]
            by_run[variant] = [statistics.median(s['requestNanoseconds'] / s['requestCount'] / 1000 for s in r['samples']) for r in records]
            assert len(values[variant]) == 30
        medians = {v: statistics.median(x) for v, x in values.items()}
        difference = medians['direct'] - medians['baseline']
        percentage = 100 * difference / medians['baseline']
        fmt = lambda v: f'{medians[v]:.3f} [{min(values[v]):.3f}–{max(values[v]):.3f}]'
        lines.append(f'| {name.split("-")[-3]} | {mode} | {fmt("baseline")} | {fmt("direct")} | {difference:+.3f} ({percentage:+.1f}%) | {statistics.median(controls["baseline"]):.3f} / {statistics.median(controls["direct"]):.3f} |')
        summaries.append({'scenario': name, 'preparation': mode, 'medianMicroseconds': medians, 'differenceMicroseconds': difference, 'differencePercent': percentage, 'perRunMedians': by_run})
    (ROOT / 'summary.md').write_text('\n'.join(lines) + '\n')
    (ROOT / 'analysis.json').write_text(json.dumps(summaries, indent=2) + '\n')
    print('\n'.join(lines), flush=True)

if __name__ == '__main__':
    if sys.argv[1:] == ['preflight']:
        preflight()
    elif sys.argv[1:] == ['sample']:
        sample()
    else:
        raise SystemExit('Use preflight or sample')
