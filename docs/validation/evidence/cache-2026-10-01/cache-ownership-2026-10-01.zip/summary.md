# Cache ownership comparison

Microseconds per complete request; median [min–max] of 30 sample means. Controls are not subtracted.

| Size | Preparation | Current cache | Direct computation | Direct minus current | Median control: current / direct |
| --- | --- | ---: | ---: | ---: | ---: |
| 5 | empty | 43.823 [42.733–45.097] | 28.047 [26.885–28.951] | -15.776 (-36.0%) | 0.020 / 0.019 |
| 5 | primed | 29.532 [28.748–32.618] | 27.837 [26.909–28.899] | -1.695 (-5.7%) | 0.021 / 0.019 |
| 8 | empty | 2284.571 [2228.147–2321.570] | 1709.961 [1658.345–1732.772] | -574.609 (-25.2%) | 0.018 / 0.017 |
| 8 | primed | 2071.849 [2026.505–2100.321] | 1708.123 [1664.356–1724.808] | -363.725 (-17.6%) | 0.048 / 0.043 |
